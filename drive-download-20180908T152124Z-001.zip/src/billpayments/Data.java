/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package billpayments;

import java.io.Serializable;

/**
 *
 * @author D E L L
 */
public class Data implements Serializable {
     String gmail;
     int cno;
   /*  int amount;
     String account;*/
    Data()
    {}
    Data(int c,String g)
    {
        gmail=g;
        cno=c;
    }
   /* Data(int am,String a)
    {
        account=a;
        amount=am;
        
    }*/
    String getName()
    {
        return gmail;
    }
    int getId()
    {
        return cno;
    }
    
}
